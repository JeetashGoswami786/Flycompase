"""Figure 3: mechanism (spectrum, dimensionality, redundancy, lesions)."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 6.5, 'axes.linewidth': 0.6,
                     'axes.edgecolor': '#52514e', 'xtick.color': '#52514e', 'ytick.color': '#52514e',
                     'text.color': '#0b0b0b'})
BLUE, ORANGE, GRAY = '#2a78d6', '#eb6834', '#7c7b76'
COL = {'REAL': BLUE, 'TYPE': ORANGE}
LAB = {'REAL': 'Real', 'TYPE': 'Type', 'WSHUF': 'W-shuf', 'DPR': 'DPR', 'ER': 'Rand.', 'ESN': 'ESN'}
A = json.load(open('analysis_CX.json'))
models = [m for m in ['REAL', 'TYPE', 'WSHUF', 'DPR', 'ER', 'ESN'] if m in A['dim']]

fig = plt.figure(figsize=(4.8, 2.9))
gs = fig.add_gridspec(2, 4, hspace=0.75, wspace=0.65)
# (a) spectra
for k, m in enumerate(['REAL', 'TYPE', 'DPR']):
    if m not in A['spectrum']: continue
    ax = fig.add_subplot(gs[0, k])
    s = A['spectrum'][m][0]
    ax.add_patch(plt.Circle((0, 0), 1, fill=False, lw=0.5, color='#bdbcb6'))
    ax.add_patch(plt.Circle((0, 0), 0.5, fill=False, lw=0.5, ls=':', color='#bdbcb6'))
    ax.scatter(s['eig_re'], s['eig_im'], s=2.5, color=COL.get(m, GRAY), lw=0, alpha=0.8)
    ax.set_xlim(-1.1, 1.1); ax.set_ylim(-1.1, 1.1); ax.set_aspect('equal')
    ax.set_xticks([-1, 0, 1]); ax.set_yticks([-1, 0, 1]); ax.tick_params(length=2, labelsize=5.5)
    n = np.mean([x['n_slow'] for x in A['spectrum'][m]])
    ax.set_title(f'{LAB[m]} ({n:.0f} slow)', fontsize=6.3, pad=2)
    if k == 0:
        ax.text(-0.45, 1.12, 'a', transform=ax.transAxes, fontweight='bold', fontsize=8.5)
        ax.set_ylabel('Im λ', fontsize=6)
    ax.set_xlabel('Re λ', fontsize=6, labelpad=1)
# (b) dimensionality
def bars(ax, key, title, letter, src='dim', fn=None):
    vals = [[fn(d) if fn else d[key] for d in A[src][m]] for m in models]
    x = np.arange(len(models))
    for xi, m, v in zip(x, models, vals):
        ax.bar(xi, np.mean(v), width=0.62, color=COL.get(m, '#bdbcb6'), zorder=2)
        ax.errorbar(xi, np.mean(v), yerr=np.std(v, ddof=1), color='#0b0b0b', lw=0.7, capsize=0, zorder=3)
    ax.set_xticks(x); ax.set_xticklabels([LAB[m] for m in models], rotation=45, ha='right', fontsize=5.5)
    ax.tick_params(length=2, labelsize=5.5); ax.set_title(title, fontsize=6.3, pad=2)
    for s in ['top', 'right']: ax.spines[s].set_visible(False)
    ax.grid(axis='y', color='#ecebe7', lw=0.5); ax.set_axisbelow(True)
    ax.text(-0.42, 1.12, letter, transform=ax.transAxes, fontweight='bold', fontsize=8.5)
ax = fig.add_subplot(gs[0, 3]); bars(ax, 'pr', 'Activity dimension (PR)', 'b')
ax = fig.add_subplot(gs[1, 0]); bars(ax, 'within_type_corr', 'Same-type |corr|', 'c')
ax = fig.add_subplot(gs[1, 1]); bars(ax, None, 'Effective rank of W', 'd', src='spectrum', fn=lambda d: d['erank'])
# (e) slow modes vs navigation error
from summarize import load
_, test = load('CX')
ax = fig.add_subplot(gs[1, 2:4])
for t, mk in [('HD', 'o'), ('PI', 's')]:
    xs, ys = [], []
    for m in models:
        ns = np.mean([d['n_slow'] for d in A['spectrum'][m]])
        e = np.mean([r['nrmse'] for r in test[(m, t)].values()])
        xs.append(ns); ys.append(e)
        ax.scatter(ns, e, s=22 if m in COL else 16, marker=mk, color=COL.get(m, '#bdbcb6'),
                   edgecolor='#fcfcfb', lw=0.6, zorder=3)
        if t == 'HD':
            off = {'REAL': (4, -7), 'TYPE': (-4, 5), 'WSHUF': (3, 3), 'DPR': (3, -7), 'ER': (-6, 4), 'ESN': (-6, 4)}[m]
            ax.annotate(LAB[m], (ns, e), xytext=off, textcoords='offset points', fontsize=5.2, color=COL.get(m, GRAY),
                        ha='right' if off[0] < 0 else 'left')
    o = np.argsort(xs); ax.plot(np.array(xs)[o], np.array(ys)[o], lw=0.6, color='#d6d5d0', zorder=1)
    ax.text(np.array(xs)[o][-1] * 1.15, np.array(ys)[o][-1], t, fontsize=5.8, va='center', color='#52514e')
ax.set_xscale('log'); ax.set_xlabel('slow modes (|λ|>0.5, log)', fontsize=6, labelpad=1)
ax.set_ylabel('test NRMSE', fontsize=6); ax.tick_params(length=2, labelsize=5.5)
ax.set_title('Slow modes vs. navigation error', fontsize=6.3, pad=2)
for s_ in ['top', 'right']: ax.spines[s_].set_visible(False)
ax.grid(color='#ecebe7', lw=0.5); ax.set_axisbelow(True)
ax.text(-0.2, 1.12, 'e', transform=ax.transAxes, fontweight='bold', fontsize=8.5)
fig.savefig('paper/fig3.pdf', bbox_inches='tight'); fig.savefig('paper/fig3.png', dpi=200, bbox_inches='tight')
print('ok')
