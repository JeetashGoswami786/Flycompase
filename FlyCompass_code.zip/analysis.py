"""Mechanism analyses on CX: spectrum, state dimensionality, within-type
redundancy, lesion tolerance (retrained readout). usage: python analysis.py"""
import numpy as np, json, scipy.sparse as sp
from core import *; from tasks import *

C = load_circuits(); c = C['CX']; N = c['N']
import sys, os
from summarize import load
res, _ = load('CX')
MODELS = sys.argv[1:] or ['REAL', 'TYPE', 'WSHUF', 'DPR', 'ER', 'ESN']
types = c['ctype']
out = {'spectrum': {}, 'dim': {}, 'lesion': {}}

def within_type_corr(X):
    """mean pairwise correlation among neurons of the same cell type (types
    with >=4 members), vs among random neuron pairs."""
    Z = (X - X.mean(0)) / (X.std(0) + 1e-9)
    R = (Z.T @ Z) / len(Z)
    wt, rnd = [], []
    rng = np.random.default_rng(0)
    for t in np.unique(types):
        idx = np.where(types == t)[0]
        if t == '' or len(idx) < 4: continue
        sub = R[np.ix_(idx, idx)]; wt.append(np.abs(sub[np.triu_indices(len(idx), 1)]).mean())
    i, j = rng.integers(0, N, 20000), rng.integers(0, N, 20000)
    ok = i != j
    return float(np.mean(wt)), float(np.abs(R[i[ok], j[ok]]).mean())

for kind in MODELS:
    sp_, dm, ls = [], [], []
    for s in range(1, 6):
        W = make_W(c, kind, np.random.default_rng(s))
        # ---- spectrum
        ev = np.linalg.eigvals(W.toarray())
        a_ = np.abs(ev)
        sv = np.linalg.svd(W.toarray(), compute_uv=False); p = sv / sv.sum()
        erank = float(np.exp(-(p * np.log(p + 1e-30)).sum()))
        sp_.append(dict(frac_slow=float((a_ > 0.5).mean()), n_slow=int((a_ > 0.5).sum()),
                        erank=erank, eig_re=ev.real[np.argsort(-a_)[:400]].tolist() if s == 1 else None,
                        eig_im=ev.imag[np.argsort(-a_)[:400]].tolist() if s == 1 else None))
        # ---- dimensionality & redundancy under the PI task
        rho, a, g = res[kind]['PI']
        enc = Encoder(np.random.default_rng(s), N, input_groups(c, 'CX'), c['side'], g)
        rng = np.random.default_rng(2000 + s)
        ntr, nva, nte = 60, 20, 40; n = ntr + nva + nte
        v, w, h, x, y = trajectories(rng, n)
        U = enc.nav(v, w, h, True, True, 0.05, rng); Y = np.stack([-x, -y], -1) / 20
        X = run(W, U, a, rho, enc.bias)
        Xf = X[WASH:, :, :40].transpose(0, 2, 1).reshape(-1, N)
        Z = (Xf - Xf.mean(0)) / (Xf.std(0) + 1e-9)
        evc = np.linalg.eigvalsh(np.cov(Z.T)); evc = np.clip(evc, 0, None)
        pr = float(evc.sum() ** 2 / (evc ** 2).sum())
        n90 = int(np.searchsorted(np.cumsum(evc[::-1]) / evc.sum(), 0.9) + 1)
        wtc, rc = within_type_corr(Xf)
        dm.append(dict(pr=pr, n90=n90, within_type_corr=wtc, random_corr=rc))
        # ---- lesion tolerance, readout retrained after lesion
        ts, ta = np.arange(WASH, T_TRIAL, SUB), np.arange(WASH, T_TRIAL)
        row = []
        for f in [0.0, 0.1, 0.2, 0.4]:
            m = np.ones(N, np.float32)
            m[np.random.default_rng(300 + s).permutation(N)[:int(f * N)]] = 0
            D = sp.diags(m); Wl = (D @ W @ D).tocsr()
            Xl = run(Wl, U * m[None, :, None], a, rho, enc.bias * m[:, None])
            keep = np.where(m > 0)[0]
            tk = lambda lo, hi, tt: (Xl[tt][:, keep, lo:hi].transpose(0, 2, 1).reshape(-1, len(keep)),
                                     Y[tt][:, lo:hi].reshape(-1, 2))
            r = fit_eval(*tk(0, ntr, ts), *tk(ntr, ntr + nva, ta), *tk(ntr + nva, n, ta))
            row.append(r['test'])
        ls.append(row)
        print(kind, s, sp_[-1]['n_slow'], round(sp_[-1]['erank'], 1), dm[-1], [round(e, 3) for e in row], flush=True)
    json.dump({'spectrum': sp_, 'dim': dm, 'lesion': ls}, open(f'analysis_CX_{kind}.json', 'w'))
