"""Main experiment: per-model hyperparameter tuning (seed 0) then 10 test seeds.
usage: python exp.py CX|MB"""
import numpy as np, itertools, json, sys, time, os
from core import *; from tasks import *

circ_name = sys.argv[1]
C = load_circuits(); c = C[circ_name]; N = c['N']
MODELS = ['REAL', 'RIO', 'TYPE', 'WSHUF', 'SSHUF', 'DPR', 'ER', 'ESN'] if circ_name == 'CX' \
    else ['REAL', 'TYPE', 'DPR', 'ER', 'ESN']
GRID = list(itertools.product([0.9, 1.05], [0.02, 0.05, 0.2], [0.1, 0.3, 1.0]))
SEEDS = range(1, 11)
GEN_SEEDS = set(range(1, 11))
GEN_GRID = list(itertools.product([0.9, 1.05], [0.05, 0.2], [0.3, 1.0]))
OUT = f'results_{circ_name}.jsonl'
done = set()
if os.path.exists(OUT):
    for l in open(OUT):
        d = json.loads(l); done.add((d['phase'], d['model'], d['task'], d.get('seed', -1)))
# readout neurons: all for CX; random 2875 for MB (matched readout dimension)
ro = np.arange(N) if circ_name == 'CX' else np.sort(np.random.default_rng(99).permutation(N)[:2875])

def log(d):
    with open(OUT, 'a') as f: f.write(json.dumps(d) + '\n')

def get_W(model, seed):
    return make_W(c, 'REAL' if model == 'RIO' else model, np.random.default_rng(seed))

def get_enc(model, seed, g):
    gr = input_groups(c, circ_name, rng=np.random.default_rng(500 + seed), random_io=(model == 'RIO'))
    return Encoder(np.random.default_rng(seed), N, gr, c['side'], g)

for model in MODELS:
    t0 = time.time()
    W0 = get_W(model, 0)
    best = {}
    # ---------- tuning (seed 0) ----------
    for task in ['PI', 'HD']:
        if ('tune', model, task, -1) in done:
            best[task] = [json.loads(l) for l in open(OUT) if json.loads(l)['phase'] == 'tune'
                          and json.loads(l)['model'] == model and json.loads(l)['task'] == task][0]['hp']
            continue
        scores = []
        for rho, a, g in GRID:
            r = nav_task(task, W0, get_enc(model, 0, g), a, rho, np.random.default_rng(0), 60, 30, 0, ro)
            scores.append((r['val'], (rho, a, g)))
        best[task] = min(scores)[1]
        log(dict(phase='tune', model=model, task=task, hp=best[task], val=min(scores)[0]))
    gen_tasks = ['NARMA', 'MG', 'MC']
    if all(('tune', model, t, -1) in done for t in gen_tasks):
        for t in gen_tasks:
            best[t] = [json.loads(l) for l in open(OUT) if json.loads(l)['phase'] == 'tune'
                       and json.loads(l)['model'] == model and json.loads(l)['task'] == t][0]['hp']
    else:
        sc = {t: [] for t in gen_tasks}
        for rho, a, g in GEN_GRID:
            r = generic_tasks(W0, get_enc(model, 0, g), a, rho, np.random.default_rng(0), ro)
            sc['NARMA'].append((r['NARMA'], (rho, a, g)))
            sc['MG'].append((r['MG'], (rho, a, g)))
            sc['MC'].append((-r['MC'], (rho, a, g)))
        for t in gen_tasks:
            best[t] = min(sc[t])[1]
            log(dict(phase='tune', model=model, task=t, hp=best[t], val=min(sc[t])[0]))
    print(circ_name, model, 'tuned', best, '%.0fs' % (time.time() - t0), flush=True)
    # ---------- test ----------
    for s in SEEDS:
        W = W0 if model in ('REAL', 'RIO') else get_W(model, s)
        for task in ['PI', 'HD']:
            if ('test', model, task, s) in done: continue
            rho, a, g = best[task]
            r = nav_task(task, W, get_enc(model, s, g), a, rho, np.random.default_rng(1000 + s), 100, 30, 60, ro)
            d = dict(phase='test', model=model, task=task, seed=s, nrmse=r['test'])
            for k in ('home_ang_deg', 'home_dist_rel', 'hd_err_deg', 'err_vs_dark'):
                if k in r: d[k] = r[k]
            log(d)
        if s not in GEN_SEEDS: continue
        hps = {}
        for t in gen_tasks: hps.setdefault(tuple(best[t]), []).append(t)
        for hp, ts in hps.items():
            if all(('test', model, t, s) in done for t in ts): continue
            rho, a, g = hp
            r = generic_tasks(W, get_enc(model, s, g), a, rho, np.random.default_rng(1000 + s), ro, test=True)
            for t in ts:
                log(dict(phase='test', model=model, task=t, seed=s, nrmse=r[t]))
    print(circ_name, model, 'done %.0fs' % (time.time() - t0), flush=True)
