"""Tasks. Matched (navigation): HD = angular integration, PI = path integration.
Unmatched (generic RC benchmarks): NARMA-10, Mackey-Glass, memory capacity."""
import numpy as np
from core import run, ridge, nrmse

T_TRIAL = 200
SUB = 4          # use every SUB-th step (t>=WASH) to fit the readout
WASH = 5
LAMS = [1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1]

# ------------------------------------------------------------ trajectories
def dark_mask(rng, T, n, light=(10, 30), dark=(10, 40)):
    m = np.zeros((T, n), bool)
    for j in range(n):
        t, d = 0, False
        L = rng.integers(*light)                   # always start in light
        while t < T:
            m[t:t + L, j] = d
            t += L; d = not d
            L = rng.integers(*(dark if d else light))
    return m

def ou(rng, n, T, mu, sig, tau):
    x = np.full(n, mu, float); out = np.empty((T, n))
    k = np.sqrt(2 / tau) * sig
    for t in range(T):
        x = x + (mu - x) / tau + k * rng.standard_normal(n)
        out[t] = x
    return out

def trajectories(rng, n, T=T_TRIAL, random_h0=True, w_sig=0.25):
    v = np.clip(ou(rng, n, T, 1.0, 0.4, 10.0), 0.0, None)          # speed
    w = ou(rng, n, T, 0.0, w_sig, 5.0)                               # ang. vel.
    h0 = rng.uniform(0, 2 * np.pi, n) if random_h0 else np.zeros(n)
    h = h0 + np.cumsum(w, 0)
    x = np.cumsum(v * np.cos(h), 0); y = np.cumsum(v * np.sin(h), 0)
    return v, w, h, x, y

class Encoder:
    """Fixed per-seed sensory encoders onto the input neuron groups."""
    def __init__(self, rng, N, groups, side, gain):
        comp, angv, spd = groups
        self.N, self.comp, self.angv, self.spd, self.g = N, comp, angv, spd, gain
        self.phi = rng.uniform(0, 2 * np.pi, len(comp))               # ER pref.
        s = np.where(side[angv] == 'left', -1.0, 1.0)
        s[side[angv] == ''] = rng.choice([-1, 1], (side[angv] == '').sum())
        if len(np.unique(s)) < 2:  # e.g. random groups: enforce push-pull
            s = rng.choice([-1.0, 1.0], len(angv))
        self.wsgn = s * rng.uniform(0.5, 1.5, len(angv))
        self.vg = rng.uniform(0.5, 1.5, len(spd))
        self.bias = (rng.uniform(-0.2, 0.2, (N, 1))).astype(np.float32)
        self.uni = np.concatenate([comp, angv, spd])
        self.wuni = rng.uniform(-1, 1, len(self.uni))

    def nav(self, v, w, h, use_compass, use_speed, noise, rng):
        T, B = v.shape
        U = np.zeros((T, self.N, B), np.float32)
        nz = lambda *s: noise * rng.standard_normal(s)
        if use_compass:
            hn = h + nz(T, B)                     # noisy compass heading
            U[:, self.comp, :] = np.cos(hn[:, None, :] - self.phi[None, :, None])
        wn = (w + 0.25 * nz(T, B)) / 0.25
        U[:, self.angv, :] = self.wsgn[None, :, None] * wn[:, None, :]
        if use_speed:
            vn = (v + 0.4 * nz(T, B) - 1.0) / 0.4
            U[:, self.spd, :] = self.vg[None, :, None] * vn[:, None, :]
        return U * self.g

    def scalar(self, u):
        T, B = u.shape
        U = np.zeros((T, self.N, B), np.float32)
        U[:, self.uni, :] = self.wuni[None, :, None] * u[:, None, :]
        return U * self.g

# --------------------------------------------------------------- readout
def fit_eval(Xtr, Ytr, Xva, Yva, Xte=None, Yte=None):
    """Xtr: (S,F) features. Picks lambda on val, returns val (and test) NRMSE."""
    def aug(X): return np.hstack([X, np.ones((len(X), 1), X.dtype)])
    A = aug(Xtr).astype(np.float64)
    XtX, XtY = A.T @ A, A.T @ Ytr
    best = None
    for lam in LAMS:
        Wo = ridge(XtX, XtY, lam)
        e = nrmse(Yva, aug(Xva) @ Wo)
        if best is None or e < best[0]: best = (e, lam, Wo)
    out = {'val': best[0], 'lam': best[1], 'Wo': best[2]}
    if Xte is not None:
        out['pred'] = aug(Xte) @ best[2]
        out['test'] = nrmse(Yte, out['pred'])
    return out

def nav_task(task, W, enc, a, rho, rng, ntr, nva, nte, ro_idx, noise=0.05,
             return_states=False):
    """task in {'HD','PI'}. Trials run in one batch; readout from ro_idx."""
    n = ntr + nva + nte
    dark = None
    if task == 'HD':
        # heading maintenance under landmark dropout: compass cue visible in
        # 'light' blocks, absent in 'dark' blocks; angular velocity always on.
        v, w, h, x, y = trajectories(rng, n, random_h0=True, w_sig=0.1)
        w = w * 2.5   # rescale so encoder normalisation (/0.25) gives unit variance
        U = enc.nav(v, w, h, use_compass=True, use_speed=False, noise=noise, rng=rng)
        dark = dark_mask(rng, T_TRIAL, n)
        U[:, enc.comp, :] *= (~dark)[:, None, :]
        Y = np.stack([np.cos(h), np.sin(h)], -1)                  # (T,B,2)
    else:
        v, w, h, x, y = trajectories(rng, n, random_h0=True)
        U = enc.nav(v, w, h, use_compass=True, use_speed=True, noise=noise, rng=rng)
        scale = 20.0
        Y = np.stack([-x, -y], -1) / scale                         # home vector
    X = run(W, U, a, rho, enc.bias)[:, ro_idx, :]                 # (T,F,B)
    ts = np.arange(WASH, T_TRIAL, SUB)
    def take(lo, hi, tt):
        Xs = X[tt][:, :, lo:hi].transpose(0, 2, 1).reshape(-1, X.shape[1])
        Ys = Y[tt][:, lo:hi].reshape(-1, 2)
        return Xs, Ys
    tall = np.arange(WASH, T_TRIAL)
    Xtr, Ytr = take(0, ntr, ts)
    Xva, Yva = take(ntr, ntr + nva, tall)
    if dark is not None:   # evaluate on dark steps only
        mva = dark[tall][:, ntr:ntr + nva].reshape(-1)
        Xva, Yva = Xva[mva], Yva[mva]
    if nte:
        Xte, Yte = take(ntr + nva, n, tall)
        if dark is not None:
            mte = dark[tall][:, ntr + nva:].reshape(-1)
            Xte_all, Yte_all = Xte, Yte
            Xte, Yte = Xte[mte], Yte[mte]
        r = fit_eval(Xtr, Ytr, Xva, Yva, Xte, Yte)
        if task == 'PI':   # endpoint homing error at final step
            P = r['pred'].reshape(len(tall), nte, 2)[-1]; G = Yte.reshape(len(tall), nte, 2)[-1]
            ang = np.abs(np.angle(np.exp(1j * (np.arctan2(P[:, 1], P[:, 0]) - np.arctan2(G[:, 1], G[:, 0])))))
            r['home_ang_deg'] = float(np.degrees(np.median(ang)))
            r['home_dist_rel'] = float(np.median(np.abs(np.linalg.norm(P, axis=1) / np.linalg.norm(G, axis=1) - 1)))
        if task == 'HD':
            P, G = r['pred'], Yte
            ang = np.abs(np.angle(np.exp(1j * (np.arctan2(P[..., 1], P[..., 0]) - np.arctan2(G[..., 1], G[..., 0])))))
            r['hd_err_deg'] = float(np.degrees(np.mean(ang)))
            # error vs. time since landmark loss
            def aug(Z): return np.hstack([Z, np.ones((len(Z), 1))])
            Pall = (aug(Xte_all) @ r['Wo']).reshape(len(tall), nte, 2)
            Gall = Yte_all.reshape(len(tall), nte, 2)
            e = np.degrees(np.abs(np.angle(np.exp(1j * (np.arctan2(Pall[..., 1], Pall[..., 0]) - np.arctan2(Gall[..., 1], Gall[..., 0]))))))
            dk = dark[tall][:, ntr + nva:]
            since = np.zeros_like(dk, int)
            for t in range(1, len(tall)):
                since[t] = np.where(dk[t], since[t - 1] + 1, 0)
            r['err_vs_dark'] = [float(e[since == k].mean()) if (since == k).any() else None for k in range(0, 41)]
        if return_states: r['X'] = X; r['h'] = h
        return r
    return fit_eval(Xtr, Ytr, Xva, Yva)

# --------------------------------------------------------- generic tasks
def narma10(rng, T):
    u = rng.uniform(0, 0.5, T); y = np.zeros(T)
    for t in range(9, T - 1):
        y[t + 1] = 0.3 * y[t] + 0.05 * y[t] * y[t - 9:t + 1].sum() + 1.5 * u[t - 9] * u[t] + 0.1
    return u, y

def mackey_glass(rng, T, tau=17, sub=3):
    n = (T + 600) * sub; x = np.full(n, 1.2) + 0.1 * rng.standard_normal(n)
    d = tau * sub // 3
    for t in range(d, n - 1):  # Euler, dt = 1/ (sub/3)
        x[t + 1] = x[t] + (3 / sub) * (0.2 * x[t - d] / (1 + x[t - d] ** 10) - 0.1 * x[t])
    return x[600 * sub::sub][:T]

GEN_T = (300, 2500, 800, 800)   # washout, train, val, test

def generic_tasks(W, enc, a, rho, rng, ro_idx, test=False):
    """Runs NARMA10, MG(10-step) and MC(1..100) together as 3 batch columns."""
    wo, tr, va, te = GEN_T; T = wo + tr + va + te
    un, yn = narma10(rng, T)
    mg = mackey_glass(rng, T + 10)
    um, ym = (mg[:T] - 0.9) / 0.25, (mg[10:T + 10] - 0.9) / 0.25
    uc = rng.uniform(-1, 1, T)
    u = np.stack([(un - 0.25) * 4, um, uc], 1)
    X = run(W, enc.scalar(u), a, rho, enc.bias)[:, ro_idx, :]
    sl = lambda lo, hi: slice(lo, hi)
    s_tr, s_va, s_te = sl(wo, wo + tr), sl(wo + tr, wo + tr + va), sl(wo + tr + va, T)
    res = {}
    for k, (col, y) in enumerate([('NARMA', yn), ('MG', ym)]):
        r = fit_eval(X[s_tr, :, k], y[s_tr, None], X[s_va, :, k], y[s_va, None],
                     X[s_te, :, k] if test else None, y[s_te, None] if test else None)
        res[col] = r['test'] if test else r['val']
    D = 100
    Yd = np.stack([np.roll(uc, d) for d in range(1, D + 1)], 1)
    r = fit_eval(X[s_tr, :, 2], Yd[s_tr], X[s_va, :, 2], Yd[s_va],
                 X[s_te, :, 2] if test else None, Yd[s_te] if test else None)
    if test:
        P, G = r['pred'], Yd[s_te]
    else:
        def aug(Z): return np.hstack([Z, np.ones((len(Z), 1))])
        P, G = aug(X[s_va, :, 2]) @ r['Wo'], Yd[s_va]
    mc = sum(max(0.0, np.corrcoef(P[:, d], G[:, d])[0, 1]) ** 2 for d in range(D))
    res['MC'] = float(mc)
    return res
