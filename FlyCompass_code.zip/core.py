"""Core library: FlyWire circuit extraction, null models, reservoir, tasks."""
import numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import eigs
import os, pickle

ANN = '/home/claude/flyconnectome/flywire_annotations/supplemental_files/Supplemental_file1_neuron_annotations.tsv'
CON = '/root/fly/Drosophila_brain_model/Connectivity_783.parquet'
CACHE = '/home/claude/flyproj/circuits.pkl'

# ----------------------------------------------------------------- circuits
def load_circuits():
    if os.path.exists(CACHE):
        return pickle.load(open(CACHE, 'rb'))
    a = pd.read_csv(ANN, sep='\t', low_memory=False)
    c = pd.read_parquet(CON)
    out = {}
    defs = {'CX': a.cell_class == 'CX',
            'MB': a.cell_class.isin(['Kenyon_Cell', 'MBON', 'DAN', 'MBIN'])}
    for name, mask in defs.items():
        sub = a[mask].reset_index(drop=True)
        idx = {r: i for i, r in enumerate(sub.root_id)}
        e = c[c.Presynaptic_ID.isin(idx) & c.Postsynaptic_ID.isin(idx)]
        pre = e.Presynaptic_ID.map(idx).values
        post = e.Postsynaptic_ID.map(idx).values
        cnt = e.Connectivity.values.astype(np.float32)
        sgn = e.Excitatory.values.astype(np.float32)
        # neuron sign = sign of its outgoing synapses (Dale); default +1
        nsign = np.ones(len(sub), np.float32)
        nsign[pre] = sgn
        S = lambda col: np.array([str(v) for v in col.fillna('').tolist()])
        ctype = S(sub.cell_type.fillna(sub.hemibrain_type))
        out[name] = dict(N=len(sub), pre=pre, post=post, cnt=cnt, nsign=nsign,
                         ctype=ctype, side=S(sub.side), cls=S(sub.cell_class),
                         top_nt=S(sub.top_nt), root=sub.root_id.values)
    pickle.dump(out, open(CACHE, 'wb'))
    return out

def input_groups(circ, name, rng=None, random_io=False):
    """Indices of neurons receiving (compass, angular velocity, speed) inputs.
    CX: ring neurons (ER*), PEN, PFN  -- biological entry points.
    MB: Kenyon cells (biological entry point of MB), random disjoint subsets of
    the same sizes as in CX so input dimensionality is matched."""
    t = circ['ctype']
    if name == 'CX':
        comp = np.where(np.char.startswith(t, 'ER'))[0]
        angv = np.where(np.char.startswith(t, 'PEN'))[0]
        spd = np.where(np.char.startswith(t, 'PFN'))[0]
    else:
        kc = np.where(circ['cls'] == 'Kenyon_Cell')[0]
        r = np.random.default_rng(12345)
        p = r.permutation(kc)
        comp, angv, spd = p[:278], p[278:320], p[320:763]
    if random_io:
        N = circ['N']
        p = rng.permutation(N)
        n1, n2, n3 = len(comp), len(angv), len(spd)
        comp, angv, spd = p[:n1], p[n1:n1+n2], p[n1+n2:n1+n2+n3]
    return comp, angv, spd

# --------------------------------------------------------------- matrices
def build(N, pre, post, w):
    # W[post, pre] : row = target
    M = sp.csr_matrix((w.astype(np.float32), (post, pre)), shape=(N, N))
    M.sum_duplicates()
    return M

def spectral_radius(M):
    try:
        v = eigs(M.astype(np.float64), k=1, which='LM', return_eigenvectors=False,
                 maxiter=20000, tol=1e-6)
        return float(np.abs(v[0]))
    except Exception:
        return float(np.max(np.abs(np.linalg.eigvals(M.toarray()))))

def real_edges(circ):
    w = circ['cnt'] * circ['nsign'][circ['pre']]
    return circ['pre'].copy(), circ['post'].copy(), w

def null_dpr(circ, rng, nswap_factor=5):
    """Directed degree-preserving rewiring (Maslov-Sneppen). Weight stays with
    the presynaptic stub, so each neuron keeps its out-weights and its sign."""
    N = circ['N']
    pre, post, w = real_edges(circ)
    pre = pre.astype(np.int64); post = post.astype(np.int64)
    E = len(pre)
    keys = set((pre * N + post).tolist())
    target = nswap_factor * E
    done = 0
    while done < target:
        k = min(E // 2, 50000)
        i = rng.integers(0, E, k); j = rng.integers(0, E, k)
        ok = (i != j)
        i, j = i[ok], j[ok]
        a, b, c_, d = pre[i], post[i], pre[j], post[j]
        ok = (a != d) & (c_ != b)
        i, j, a, b, c_, d = i[ok], j[ok], a[ok], b[ok], c_[ok], d[ok]
        acc = 0
        for ii, jj, aa, bb, cc, dd in zip(i, j, a, b, c_, d):
            k1, k2 = aa * N + dd, cc * N + bb
            if k1 in keys or k2 in keys or pre[ii] != aa or pre[jj] != cc \
               or post[ii] != bb or post[jj] != dd:
                continue
            keys.discard(aa * N + bb); keys.discard(cc * N + dd)
            keys.add(k1); keys.add(k2)
            post[ii], post[jj] = dd, bb
            acc += 1
        done += acc
    return pre, post, w

def null_wshuf(circ, rng):
    """Same topology; synapse magnitudes permuted across edges; Dale's law kept."""
    pre, post, _ = real_edges(circ)
    mag = rng.permutation(circ['cnt'])
    return pre, post, mag * circ['nsign'][pre]

def null_sshuf(circ, rng):
    """Same topology and magnitudes; E/I identities permuted across neurons."""
    pre, post, _ = real_edges(circ)
    ns = rng.permutation(circ['nsign'])
    return pre, post, circ['cnt'] * ns[pre]

def null_er(circ, rng):
    """Erdos-Renyi directed graph, same N and edge count; empirical magnitudes,
    E/I identities permuted across neurons (Dale kept)."""
    N = circ['N']; E = len(circ['pre'])
    keys = np.unique(rng.integers(0, N * N, int(E * 1.1)))
    keys = keys[(keys // N) != (keys % N)]
    keys = rng.permutation(keys)[:E]
    pre, post = keys // N, keys % N
    ns = rng.permutation(circ['nsign'])
    return pre, post, rng.permutation(circ['cnt']) * ns[pre]

def null_esn(circ, rng):
    """Classic ESN: same N and density, uniform(-1,1) weights, no Dale's law."""
    N = circ['N']; E = len(circ['pre'])
    keys = np.unique(rng.integers(0, N * N, int(E * 1.1)))
    keys = rng.permutation(keys)[:E]
    return keys // N, keys % N, rng.uniform(-1, 1, len(keys)).astype(np.float32)

def null_type(circ, rng):
    """Cell-type-preserving null: every edge keeps its weight and the cell
    types of its endpoints, but each endpoint is re-drawn uniformly among the
    neurons of the same type. Preserves the type-to-type wiring diagram
    (a stochastic block model at cell-type resolution); destroys
    neuron-specific (e.g. columnar) wiring."""
    t = circ['ctype'].copy()
    t[t == ''] = np.array(['_u%d' % i for i in np.where(t == '')[0]])
    _, tid = np.unique(t, return_inverse=True)
    order = np.argsort(tid, kind='stable')
    starts = np.searchsorted(tid[order], np.arange(tid.max() + 1))
    counts = np.bincount(tid)
    pre, post, w = real_edges(circ)
    def redraw(x):
        k = tid[x]
        return order[starts[k] + (rng.random(len(x)) * counts[k]).astype(int)]
    p2, q2 = redraw(pre), redraw(post)
    ok = p2 != q2
    ns = circ['nsign']
    return p2[ok], q2[ok], circ['cnt'][ok] * ns[p2[ok]]

NULLS = {'TYPE': null_type, 'DPR': null_dpr, 'WSHUF': null_wshuf, 'SSHUF': null_sshuf,
         'ER': null_er, 'ESN': null_esn}

def input_normalize(M):
    """Express each synapse as a fraction of the target neuron's total input
    (row-normalisation of |W|), keeping signs."""
    tot = np.asarray(abs(M).sum(1)).ravel()
    tot[tot == 0] = 1.0
    return sp.diags(1.0 / tot).dot(M).tocsr()

def make_W(circ, kind, rng, norm='raw'):
    if kind in ('REAL', 'RIO'):
        pre, post, w = real_edges(circ)
    else:
        pre, post, w = NULLS[kind](circ, rng)
    M = build(circ['N'], pre, post, w)
    if norm == 'frac' and kind != 'ESN':
        M = input_normalize(M)
    elif norm == 'log' and kind != 'ESN':
        M.data = np.sign(M.data) * np.log1p(np.abs(M.data))
    return M / spectral_radius(M)

# --------------------------------------------------------------- reservoir
def run(W, Uin, a, rho, bias, collect=None):
    """Leaky tanh reservoir. W: (N,N) unit-spectral-radius sparse.
    Uin: (T, N, B) input drive (already projected).  Returns states (T,N,B)
    or calls collect(t, x) to save memory."""
    T, N, B = Uin.shape
    Ws = (W * rho).astype(np.float32).tocsr()
    x = np.zeros((N, B), np.float32)
    out = None if collect else np.empty((T, N, B), np.float32)
    for t in range(T):
        x = (1 - a) * x + a * np.tanh(Ws @ x + Uin[t] + bias)
        if collect: collect(t, x)
        else: out[t] = x
    return out

def ridge(XtX, XtY, lam):
    n = XtX.shape[0]
    return np.linalg.solve(XtX + lam * np.trace(XtX) / n * np.eye(n), XtY)

def nrmse(y, yh):
    return float(np.sqrt(np.mean((y - yh) ** 2)) / (np.std(y) + 1e-12))
