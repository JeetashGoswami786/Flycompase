import json, os
out = {'spectrum': {}, 'dim': {}, 'lesion': {}}
for m in ['REAL', 'TYPE', 'WSHUF', 'DPR', 'ER', 'ESN']:
    f = f'analysis_CX_{m}.json'
    if os.path.exists(f):
        d = json.load(open(f))
        for k in out: out[k][m] = d[k]
json.dump(out, open('analysis_CX.json', 'w')); print(list(out['dim']))
