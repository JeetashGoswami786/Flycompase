"""New Figure 1: real 3D FlyWire neurons + wiring matrices + path-integration task."""
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from PIL import Image
from core import *; from tasks import *

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7, 'axes.linewidth': 0.6,
                     'axes.edgecolor': '#52514e', 'text.color': '#0b0b0b'})
BLUE, ORANGE, GRAY = '#2a78d6', '#eb6834', '#8a8984'
seq = LinearSegmentedColormap.from_list('seq', ['#fcfcfb', '#cfe0f5', '#6ea6e6', '#2a78d6', '#0d3d78'])
FAMC = [('#3987e5', 'Ring (ER)'), ('#f07a3f', 'Compass (EPG/PEN/Δ7)'), ('#22c08a', 'Self-motion (PFN)'),
        ('#9085e9', 'FB columnar'), ('#e87ba4', 'FB tangential')]

C = load_circuits(); c = C['CX']; N = c['N']; t = c['ctype']
def family(x):
    for p in ['ER', 'EPG', 'PEN', 'PEG', 'Delta7', 'PFN', 'hDelta', 'vDelta', 'PFL', 'PFR', 'PFG', 'FC', 'FS', 'FR', 'FB', 'ExR', 'EL', 'SA']:
        if x.startswith(p): return p
    return 'other'
famorder = ['ER', 'EPG', 'PEN', 'PEG', 'Delta7', 'PFN', 'hDelta', 'vDelta', 'PFL', 'PFR', 'PFG', 'FC', 'FS', 'FR', 'FB', 'ExR', 'EL', 'SA', 'other']
fam = np.array([family(x) for x in t]); rank = {f: i for i, f in enumerate(famorder)}
order = np.lexsort((t, [rank[f] for f in fam])); inv = np.empty(N, int); inv[order] = np.arange(N)
def binned(pre, post, w, B=144):
    M = np.zeros((B, B)); np.add.at(M, (inv[post] * B // N, inv[pre] * B // N), np.abs(w)); return np.log10(1 + M)

fig = plt.figure(figsize=(4.8, 3.75))
gs = fig.add_gridspec(2, 1, height_ratios=[1.12, 1], hspace=0.2)
top = gs[0].subgridspec(1, 2, width_ratios=[1.62, 1], wspace=0.03)
bot = gs[1].subgridspec(1, 4, wspace=0.28)

brain = np.asarray(Image.open('paper/render_brain_light_crop.png'))
cx = np.asarray(Image.open('paper/render_cx_light_crop.png'))
ax = fig.add_subplot(top[0]); ax.imshow(brain); ax.axis('off')
ax.set_title('Whole fly brain (FlyWire meshes)', fontsize=6.8, pad=2)
ax.text(-0.02, 1.02, 'a', transform=ax.transAxes, fontweight='bold', fontsize=9)
LEGX = [0.03, 0.19, 0.42, 0.62, 0.79]
ax2 = fig.add_subplot(top[1]); ax2.imshow(cx); ax2.axis('off')
ax2.set_title('Central complex', fontsize=6.8, pad=2)
ax2.text(-0.02, 1.02, 'b', transform=ax2.transAxes, fontweight='bold', fontsize=9)

fig.canvas.draw()
yl = ax.get_position().y0 - 0.012
for (col, lab), xx in zip(FAMC, LEGX):
    fig.text(xx, yl, '●', color=col, fontsize=7.5, va='top')
    fig.text(xx + 0.022, yl - 0.002, lab, fontsize=5.8, va='top', color='#0b0b0b')
mats = [('Real wiring', real_edges(c)), ('Type null', null_type(c, np.random.default_rng(1))),
        ('Rewired null', null_dpr(c, np.random.default_rng(1)))]
vmax = max(binned(*m).max() for _, m in mats)
bounds = [np.searchsorted(np.array([rank[f] for f in fam[order]]), rank[f]) for f in famorder]
for k, (name, (pre, post, w)) in enumerate(mats):
    ax = fig.add_subplot(bot[k])
    ax.imshow(binned(pre, post, w), cmap=seq, vmin=0, vmax=vmax, interpolation='nearest')
    ax.set_title(name, fontsize=6.8, pad=2); ax.set_xticks([]); ax.set_yticks([])
    ax.set_xlabel('presynaptic', fontsize=5.6, labelpad=1)
    if k == 0:
        for f in ['ER', 'EPG', 'hDelta', 'vDelta', 'FB']:
            b = bounds[famorder.index(f)] * 144 / N
            ax.text(-3, b + 2, f.replace('Delta', 'Δ'), ha='right', va='top', fontsize=5, color='#52514e')
        ax.set_ylabel('postsyn. (by type)', fontsize=5.6, labelpad=11)
    ax.text(-0.12 if k else -0.62, 1.08, 'cde'[k], transform=ax.transAxes, fontweight='bold', fontsize=9)

rng = np.random.default_rng(4); v, w, h, x, y = trajectories(rng, 1)
ax = fig.add_subplot(bot[3])
ax.plot(x[:, 0], y[:, 0], color=GRAY, lw=1.0)
ax.plot([0], [0], 'o', ms=4, color=BLUE, mec='#fcfcfb', mew=1)
ax.annotate('', xy=(0, 0), xytext=(x[-1, 0], y[-1, 0]), arrowprops=dict(arrowstyle='->', color=ORANGE, lw=1.4))
ax.text(0, 0, ' home', fontsize=5.6, va='center')
ax.set_aspect('equal', adjustable='datalim'); ax.set_box_aspect(1); ax.set_xticks([]); ax.set_yticks([])
for s in ax.spines.values(): s.set_color('#d6d5d0')
ax.set_title('Path integration', fontsize=6.8, pad=2)
ax.text(-0.12, 1.08, 'f', transform=ax.transAxes, fontweight='bold', fontsize=9)
fig.savefig('paper/fig1.pdf', bbox_inches='tight', dpi=600); fig.savefig('paper/fig1.png', dpi=220, bbox_inches='tight')
print('ok')
