"""Download FlyWire v783 meshes for a representative set of central-complex
neurons (per functional family), decimate, and save one merged mesh per family.
Also build a translucent brain shell from the positions of all 139k neurons."""
import pickle, numpy as np, pandas as pd, pyvista as pv, os
from concurrent.futures import ThreadPoolExecutor
from cloudvolume import CloudVolume
from scipy.ndimage import gaussian_filter
from skimage.measure import marching_cubes

os.makedirs('meshes', exist_ok=True)
C = pickle.load(open('circuits.pkl', 'rb'))['CX']
t, roots, side = C['ctype'], C['root'], C['side']

def fam(x):
    if x.startswith('ER'): return 'ring'
    if x.startswith(('EPG', 'PEN', 'PEG', 'Delta7')): return 'compass'
    if x.startswith('PFN'): return 'pfn'
    if x.startswith(('hDelta', 'vDelta', 'FC', 'PFL', 'PFR', 'PFG')): return 'columnar'
    return 'tangential'
F = np.array([fam(x) for x in t])
N_PICK = {'compass': 9999, 'ring': 70, 'pfn': 90, 'columnar': 90, 'tangential': 45}
rng = np.random.default_rng(3)
pick = {}
for f, n in N_PICK.items():
    idx = np.where(F == f)[0]
    if f == 'tangential':   # prefer named FB/ExR tangential types, skip unlabeled
        idx = idx[np.array([s.startswith(('FB', 'ExR')) for s in t[idx]])]
    pick[f] = rng.permutation(idx)[:min(n, len(idx))]
print({f: len(v) for f, v in pick.items()})

vol = CloudVolume('precomputed://https://storage.googleapis.com/flywire_v141_m783', use_https=True,
                  progress=False, parallel=1)

def fetch(rid):
    for lod in (3, 2, 1):
        try:
            m = vol.mesh.get(int(rid), lod=lod)
            m = m[int(rid)] if isinstance(m, dict) else m
            if len(m.faces) == 0: continue
            faces = np.c_[np.full(len(m.faces), 3), m.faces].ravel()
            pm = pv.PolyData(m.vertices.astype(np.float32) / 1000.0, faces)   # nm -> um
            if pm.n_cells > 40000:
                pm = pm.decimate(1 - 40000 / pm.n_cells)
            return pm
        except Exception:
            continue
    return None

for f, idx in pick.items():
    with ThreadPoolExecutor(12) as ex:
        ms = [m for m in ex.map(fetch, roots[idx]) if m is not None]
    merged = pv.merge(ms) if len(ms) > 1 else ms[0]
    merged.save(f'meshes/{f}.vtk')
    print(f, len(ms), 'neurons', merged.n_points, 'pts', flush=True)

# ---- brain shell from neuron positions (density isosurface)
a = pd.read_parquet('positions.parquet')
P = np.c_[a.pos_x * 4, a.pos_y * 4, a.pos_z * 40] / 1000.0     # um
res = 4.0
lo = P.min(0) - 30; hi = P.max(0) + 30
shape = np.ceil((hi - lo) / res).astype(int)
H, _ = np.histogramdd(P, bins=shape, range=list(zip(lo, hi)))
D = gaussian_filter(H, sigma=4.5)
lvl = np.percentile(D[D > 0], 38)
v, fcs, _, _ = marching_cubes(D, level=lvl)
v = v * res + lo
shell = pv.PolyData(v.astype(np.float32), np.c_[np.full(len(fcs), 3), fcs].ravel())
shell = shell.smooth(n_iter=60).decimate(0.7)
shell.save('meshes/brain_shell.vtk')
print('shell', shell.n_points)
