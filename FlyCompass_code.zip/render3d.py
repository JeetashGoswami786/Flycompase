"""Render real FlyWire v783 central-complex neurons in 3D (pyvista, offscreen)."""
import numpy as np, pyvista as pv, sys
pv.OFF_SCREEN = True
FAM = [('ring', '#3987e5', 'Ring neurons (landmark/compass input)'),
       ('compass', '#f07a3f', 'Compass ring (EPG, PEN, PEG, Δ7)'),
       ('pfn', '#22c08a', 'Self-motion (PFN)'),
       ('columnar', '#9085e9', 'Fan-shaped body columnar'),
       ('tangential', '#e87ba4', 'Fan-shaped body tangential')]
M = {f: pv.read(f'meshes/{f}.vtk') for f, _, _ in FAM}
shell = pv.read('/usr/local/lib/python3.13/dist-packages/flybrains/meshes/FLYWIRE.ply')
shell.points = shell.points / 1000.0   # nm -> um (official FlyWire brain surface)
shell = shell.smooth(n_iter=8)
cx_center = np.mean([M[f].center for f in M], axis=0)

def scene(theme, size, view):
    bg = '#0b0f17' if theme == 'dark' else 'white'
    p = pv.Plotter(off_screen=True, window_size=size)
    p.set_background(bg)
    if view == 'brain':
        p.add_mesh(shell, color='#9fb3c8' if theme == 'dark' else '#8c8a84',
                   opacity=0.16 if theme == 'dark' else 0.17, smooth_shading=True, specular=0.2)
    for f, c, _ in FAM:
        p.add_mesh(M[f], color=c, smooth_shading=True, specular=0.45, specular_power=18,
                   ambient=0.18 if theme == 'dark' else 0.12, diffuse=0.85)
    # FAFB axes: x lateral, y ventral (down), z posterior. Frontal view = look along +z.
    if view == 'brain':
        foc = np.array(shell.center); dist = 1250
        cam = foc + np.array([-150, -330, -dist])
        p.camera_position = [tuple(cam), tuple(foc), (0, -1, 0)]
        p.camera.view_angle = 26
    else:   # oblique close-up of the central complex from anterior-dorsal
        foc = cx_center + np.array([0, 15, 0]); cam = foc + np.array([-190, -330, -380])
        p.camera_position = [tuple(cam), tuple(foc), (0, -1, 0)]
        p.camera.view_angle = 30
    p.enable_anti_aliasing('ssaa')
    return p

for theme in ('dark', 'light'):
    for view, size in (('brain', (2400, 1400)), ('cx', (1800, 1400))):
        p = scene(theme, size, view)
        p.screenshot(f'paper/render_{view}_{theme}.png', transparent_background=False)
        p.close()
        print(view, theme, flush=True)
