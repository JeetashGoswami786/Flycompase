"""LaTeX table of main CX results."""
import numpy as np
from summarize import table, load

out, tune, test = table('CX')
LAB = {'REAL': '\\textsc{Real}', 'RIO': '\\textsc{RIO}', 'TYPE': '\\textsc{Type}', 'WSHUF': '\\textsc{WShuf}',
       'SSHUF': '\\textsc{SShuf}', 'DPR': '\\textsc{DPR}', 'ER': '\\textsc{ER}', 'ESN': '\\textsc{ESN}'}
models = [r[0] for r in out['PI']]
def cell(t, m, key='nrmse', fmt='{:.3f}', deg=False):
    d = test.get((m, t), {})
    v = np.array([x[key] for x in d.values() if key in x])
    if len(v) == 0: return '--'
    s = fmt.format(v.mean())
    row = [r for r in out[t] if r[0] == m]
    if key == 'nrmse' and row and m != 'REAL':
        pa = row[0][6]; better = (row[0][4] > 1) if t == 'MC' else (row[0][4] < 1)
        if pa < 0.05: s = ('\\textbf{' + s + '}') if better else ('\\underline{' + s + '}')
    return s
lines = []
lines.append('\\begin{table}[t]\n\\centering\n\\caption{Central-complex results (mean over held-out seeds). Bold: significantly better than \\textsc{Real}; underlined: significantly worse (paired Wilcoxon, Holm-corrected $p<0.05$). HD$^\\circ$ = heading error in darkness; Home$^\\circ$ = homing-direction error; MC = memory capacity (higher is better).}\n\\label{tab:main}\n\\setlength{\\tabcolsep}{4pt}\n\\begin{tabular}{@{}lrrrrrrr@{}}\n\\toprule')
lines.append(' & \\multicolumn{4}{c}{Matched (navigation)} & \\multicolumn{3}{c}{Unmatched (generic)}\\\\\n\\cmidrule(lr){2-5}\\cmidrule(l){6-8}')
lines.append('Model & HD & HD$^\\circ$ & PI & Home$^\\circ$ & NARMA & MG & MC\\\\\n\\midrule')
for m in models:
    lines.append(f"{LAB[m]} & {cell('HD', m)} & {cell('HD', m, 'hd_err_deg', '{:.1f}')} & {cell('PI', m)} & "
                 f"{cell('PI', m, 'home_ang_deg', '{:.1f}')} & {cell('NARMA', m)} & {cell('MG', m)} & {cell('MC', m, fmt='{:.1f}')}\\\\")
lines.append('\\bottomrule\n\\end{tabular}\n\\end{table}')
open('paper/table_main.tex', 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
