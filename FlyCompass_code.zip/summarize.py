"""Aggregate results: tables, stats (paired Wilcoxon + Holm), best HPs."""
import json, numpy as np, sys, collections
from scipy.stats import wilcoxon

def load(circ):
    R = [json.loads(l) for l in open(f'results_{circ}.jsonl')]
    tune = {}
    for d in R:
        if d['phase'] == 'tune': tune.setdefault(d['model'], {})[d['task']] = d['hp']
    test = collections.defaultdict(dict)   # (model,task) -> seed -> record
    for d in R:
        if d['phase'] == 'test': test[(d['model'], d['task'])][d['seed']] = d
    return tune, test

def holm(ps):
    idx = np.argsort(ps); m = len(ps); adj = np.empty(m); run = 0
    for r, i in enumerate(idx):
        run = max(run, (m - r) * ps[i]); adj[i] = min(1, run)
    return adj

def table(circ, key='nrmse'):
    tune, test = load(circ)
    models = [m for m in ['REAL', 'RIO', 'TYPE', 'WSHUF', 'SSHUF', 'DPR', 'ER', 'ESN'] if (m, 'PI') in test]
    tasks = ['HD', 'PI', 'NARMA', 'MG', 'MC']
    out = {}
    for t in tasks:
        ref = test.get(('REAL', t), {})
        rows, ps = [], []
        for m in models:
            d = test.get((m, t), {})
            seeds = sorted(set(d) & set(ref))
            v = np.array([d[s][key] for s in seeds]); r = np.array([ref[s][key] for s in seeds])
            if len(v) == 0: continue
            p = 1.0 if m == 'REAL' or len(v) < 5 or np.allclose(v, r) else wilcoxon(v, r).pvalue
            rows.append([m, v.mean(), v.std(ddof=1) if len(v) > 1 else 0, len(v), np.mean(v / r), p])
            ps.append(p)
        adj = holm(np.array([r[5] for r in rows if r[0] != 'REAL'])) if len(rows) > 1 else []
        k = 0
        for r in rows:
            if r[0] != 'REAL': r.append(adj[k]); k += 1
            else: r.append(np.nan)
        out[t] = rows
    return out, tune, test

if __name__ == '__main__':
    for circ in sys.argv[1:]:
        out, tune, test = table(circ)
        json.dump(tune, open(f'best_hp_{circ}.json', 'w'))
        print('=====', circ)
        for t, rows in out.items():
            print('--', t, '(MC: higher=better)' if t == 'MC' else '')
            for m, mu, sd, n, ratio, p, pa in rows:
                print(f'  {m:6s} {mu:.4f} ± {sd:.4f} (n={n})  ratio/REAL={ratio:.3f}  p={p:.4f}  p_holm={pa:.4f}')
        for m in ['REAL', 'TYPE', 'DPR', 'ER', 'ESN']:
            for k in ['hd_err_deg', 'home_ang_deg', 'home_dist_rel']:
                for t in ['HD', 'PI']:
                    d = test.get((m, t), {})
                    vals = [x[k] for x in d.values() if k in x]
                    if vals: print(f'  {m} {t} {k}: {np.mean(vals):.2f} ± {np.std(vals, ddof=1) if len(vals)>1 else 0:.2f}')
