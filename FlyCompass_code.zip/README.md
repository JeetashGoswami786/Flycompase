# Does the Fly's Compass Wiring Matter? — code

Function-matched evaluation of the FlyWire *Drosophila* central-complex connectome as a reservoir, against a seven-level null-model hierarchy.

## Data (all open)
- FlyWire v783 connectivity with signs: `Connectivity_783.parquet` from https://github.com/philshiu/Drosophila_brain_model (Shiu et al., Nature 2024)
- Cell-type annotations: `Supplemental_file1_neuron_annotations.tsv` from https://github.com/flyconnectome/flywire_annotations (Schlegel et al., Nature 2024)

Edit the `ANN` and `CON` paths at the top of `core.py` to point to these files.

## Requirements
Python 3.10+, numpy, scipy, pandas, pyarrow, matplotlib.

## Files
| File | Purpose |
|---|---|
| `core.py` | circuit extraction (CX, MB), null models (Type, WShuf, SShuf, DPR, ER, ESN), leaky reservoir, ridge readout |
| `tasks.py` | heading maintenance under landmark loss, path integration, NARMA-10, Mackey–Glass, memory capacity |
| `exp.py` | per-model hyperparameter tuning + 10 held-out seeds (`python exp.py CX` / `python exp.py MB`); resumable |
| `analysis.py` | spectra, activity dimensionality, within-type correlation, lesions (`python analysis.py REAL TYPE ...`) |
| `summarize.py` | tables and paired Wilcoxon tests with Holm correction |
| `get_meshes.py`, `render3d.py` | download real FlyWire neuron meshes (storage.googleapis.com/flywire_v141_m783) and render them (pyvista; brain surface from `flybrains`) |
| `fig1b.py`, `fig3.py`, `make_table.py`, `merge_analysis.py` | paper figures and table |
| `results_CX.jsonl`, `results_MB.jsonl`, `analysis_CX.json` | raw results used in the paper |

## Reproduce
```
python exp.py CX; python exp.py MB          # ~4-6 h on 2 CPU cores
python analysis.py; python merge_analysis.py
python summarize.py CX MB; python make_table.py; python get_meshes.py; python render3d.py; python fig1b.py; python fig3.py
```
